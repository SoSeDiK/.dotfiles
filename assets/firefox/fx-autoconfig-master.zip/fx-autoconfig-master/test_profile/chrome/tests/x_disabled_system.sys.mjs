// ==UserScript==
// @name           x_disabled_system_module
// @loadOrder      1
// ==/UserScript==
// This file should not run because it is disabled by pref
console.warn("Disabled script isn't supposed to run!");
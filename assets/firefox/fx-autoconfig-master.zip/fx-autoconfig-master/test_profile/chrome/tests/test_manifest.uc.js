// ==UserScript==
// @name            test_registering_manifest
// @manifest        test_manifest
// ==/UserScript== 